

class A
{
	public static void main(String args[])
	{
		B o=new B();
		o.show();
	}
}