

class B
{
   void show()
   {
	   System.out.println("hello");
   }
}