import java.io.*;
public class Base
{
	int z;
}