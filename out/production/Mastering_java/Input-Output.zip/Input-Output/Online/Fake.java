class Fake
{
	public static void main (String...s)
	{
		int x[];
		int z=0/1;
		x=new int[z];
		
		for(int i=0 ; i< x.length ; i++)
		{
			System.out.println(x[i]);
		}
		
	}
}