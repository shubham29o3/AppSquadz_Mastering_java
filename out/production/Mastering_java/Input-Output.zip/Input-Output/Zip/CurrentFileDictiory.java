class CurrentFileDictiory
{
	public static void main(String...s)
	{
		String currentDictiory= System.getProperty("user.dir");
		System.out.println(currentDictiory);
		
		
		//System.out.println(System.getProperty("user.dir"));
	}
}