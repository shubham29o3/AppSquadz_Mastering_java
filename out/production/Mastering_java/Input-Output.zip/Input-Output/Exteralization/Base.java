import java.io.*;

class Base
{
	int z;
}